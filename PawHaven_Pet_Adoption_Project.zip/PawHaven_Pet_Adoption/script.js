const pets = [
  {id:1,name:"Buddy",type:"Dog",age:"2 years",gender:"Male",description:"A playful, loyal friend who loves walks and sunny afternoons.",image:"https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=800&q=80"},
  {id:2,name:"Luna",type:"Cat",age:"1 year",gender:"Female",description:"A gentle little explorer who enjoys cozy naps and quiet company.",image:"https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=800&q=80"},
  {id:3,name:"Coco",type:"Rabbit",age:"8 months",gender:"Female",description:"A curious, soft-hearted bunny who loves fresh greens and gentle pets.",image:"https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?auto=format&fit=crop&w=800&q=80"},
  {id:4,name:"Max",type:"Dog",age:"3 years",gender:"Male",description:"An affectionate companion with a big heart and a happy tail.",image:"https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=800&q=80"},
  {id:5,name:"Misty",type:"Cat",age:"10 months",gender:"Female",description:"A sweet, curious kitten who likes window watching and soft blankets.",image:"https://images.unsplash.com/photo-1573865526739-10659fec78a5?auto=format&fit=crop&w=800&q=80"},
  {id:6,name:"Ollie",type:"Rabbit",age:"1 year",gender:"Male",description:"A friendly bunny with a playful personality and adorable little hops.",image:"https://images.unsplash.com/photo-1535241749838-299277b6305f?auto=format&fit=crop&w=800&q=80"}
];

const petGrid = document.getElementById("petGrid");
const searchInput = document.getElementById("searchInput");
const noResults = document.getElementById("noResults");
let activeFilter = "All";

function renderPets() {
  const search = searchInput.value.trim().toLowerCase();
  const visiblePets = pets.filter(pet =>
    (activeFilter === "All" || pet.type === activeFilter) &&
    pet.name.toLowerCase().includes(search)
  );

  petGrid.innerHTML = "";
  noResults.hidden = visiblePets.length !== 0;

  visiblePets.forEach(pet => {
    const card = document.createElement("article");
    card.className = "pet-card";

    const imageWrap = document.createElement("div");
    imageWrap.className = "pet-image-wrap";

    const image = document.createElement("img");
    image.className = "pet-image";
    image.src = pet.image;
    image.alt = `${pet.name}, a ${pet.type.toLowerCase()} available for adoption`;
    image.loading = "lazy";
    image.onerror = () => {
      image.style.display = "none";
      imageWrap.style.background = "#eaf2e8";
      imageWrap.innerHTML = '<span style="display:grid;place-items:center;height:100%;font-size:5rem">🐾</span>';
    };

    const tag = document.createElement("span");
    tag.className = "pet-tag";
    tag.textContent = pet.type;
    imageWrap.append(image, tag);

    const content = document.createElement("div");
    content.className = "pet-content";
    const titleRow = document.createElement("div");
    titleRow.className = "pet-title-row";
    const title = document.createElement("h3");
    title.textContent = pet.name;
    const age = document.createElement("span");
    age.className = "pet-age";
    age.textContent = pet.age;
    titleRow.append(title, age);

    const description = document.createElement("p");
    description.className = "pet-description";
    description.textContent = pet.description;

    const footer = document.createElement("div");
    footer.className = "pet-footer";
    const gender = document.createElement("span");
    gender.className = "pet-gender";
    gender.textContent = `♀/♂ ${pet.gender}`;
    const button = document.createElement("button");
    button.className = "adopt-btn";
    button.textContent = "Meet " + pet.name + " →";
    button.addEventListener("click", () => openAdoptionForm(pet));
    footer.append(gender, button);

    content.append(titleRow, description, footer);
    card.append(imageWrap, content);
    petGrid.appendChild(card);
  });
}

document.querySelectorAll(".filter-btn").forEach(button => {
  button.addEventListener("click", () => {
    activeFilter = button.dataset.filter;
    document.querySelectorAll(".filter-btn").forEach(btn => btn.classList.remove("active"));
    button.classList.add("active");
    renderPets();
  });
});
searchInput.addEventListener("input", renderPets);

const adoptDialog = document.getElementById("adoptDialog");
function openAdoptionForm(pet) {
  document.getElementById("selectedPet").value = pet.name;
  document.getElementById("selectedPetText").textContent = `You’re interested in adopting ${pet.name}. Fill in the details below to register your interest.`;
  document.getElementById("adoptFeedback").textContent = "";
  adoptDialog.showModal();
}
document.getElementById("closeDialog").addEventListener("click", () => adoptDialog.close());
adoptDialog.addEventListener("click", event => {
  if (event.target === adoptDialog) adoptDialog.close();
});

document.getElementById("adoptForm").addEventListener("submit", event => {
  event.preventDefault();
  const formData = Object.fromEntries(new FormData(event.currentTarget).entries());
  const requests = JSON.parse(localStorage.getItem("pawhavenAdoptionRequests") || "[]");
  requests.push({...formData, submittedAt:new Date().toISOString()});
  localStorage.setItem("pawhavenAdoptionRequests", JSON.stringify(requests));
  document.getElementById("adoptFeedback").textContent =
    `Thank you, ${formData.name}! Your interest in ${formData.pet} has been saved in this browser demo.`;
  event.currentTarget.reset();
});

document.getElementById("contactForm").addEventListener("submit", event => {
  event.preventDefault();
  const formData = Object.fromEntries(new FormData(event.currentTarget).entries());
  const messages = JSON.parse(localStorage.getItem("pawhavenMessages") || "[]");
  messages.push({...formData, submittedAt:new Date().toISOString()});
  localStorage.setItem("pawhavenMessages", JSON.stringify(messages));
  document.getElementById("contactFeedback").textContent =
    "Thanks! Your message has been saved in this browser demo.";
  event.currentTarget.reset();
});

const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

renderPets();
