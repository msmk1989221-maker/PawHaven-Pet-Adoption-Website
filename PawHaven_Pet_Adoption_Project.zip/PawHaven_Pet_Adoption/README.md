# PawHaven — Pet Adoption Website

A responsive beginner-friendly frontend project made with HTML, CSS, and JavaScript.

## Files
- `index.html` — page structure and forms
- `style.css` — responsive styling and layout
- `script.js` — pet cards, search, filters, adoption form, and contact form

## Run
1. Extract the ZIP file.
2. Open the `PawHaven_Pet_Adoption` folder in VS Code.
3. Open `index.html` using Live Server, or double-click it to open in a browser.
4. Internet access is needed for Google Fonts and the remote pet photos.

## Features
- Responsive navigation and mobile menu
- Pet listing cards
- Search by pet name
- Filter by dog, cat, or rabbit
- Adoption interest modal form
- Contact form
- Demo form submissions saved in browser localStorage

## Important
This is a frontend demonstration, not a real adoption service. Forms are stored only in the current browser and do not send email or contact a shelter. Replace the sample contact details and pet information before presenting it as a real service.
